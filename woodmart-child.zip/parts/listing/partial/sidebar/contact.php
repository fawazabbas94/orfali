<div class="sidebar-widget contact">
    <div class="widget-header">
        <h3>Have us call you</h3>
        <p>Leave us your information and one of our property experts will call you.</p>
    </div>
    <?php echo do_shortcode('[contact-form-7 id="affbf59" title="Contact form 1"]'); ?>
</div>