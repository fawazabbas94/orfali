<div class="listing-sidebar">
    <?php get_template_part('parts/listing/partial/sidebar/video', get_post_format()); ?>
    <div class="sticky">
        <?php get_template_part('parts/listing/partial/sidebar/agent', get_post_format()); ?>
        <?php get_template_part('parts/listing/partial/sidebar/contact', get_post_format()); ?>
    </div>
</div>